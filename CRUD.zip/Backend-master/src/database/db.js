//Se exporta la Base de Datos 

module.exports = {
    db: "mongodb://localhost:27017/almacenamientoTienda"
}
